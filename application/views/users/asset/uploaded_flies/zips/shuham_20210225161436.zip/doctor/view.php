<?php include 'connection.php';?>

<html>
<head>
<title></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

	<body>
		<div class="container">
			<table class="table table-hover">
				<thead>
					<tr>
						<th>SR_no</th>
						<th>Fullname</th>
						<th>Age</th>
						<th>Height</th>
						<th>Weight</th>
						<th>Mobile</th>
						<th>Date of App</th>
					</tr>
				</thead>
				
				<tbody>
					<?php
					$sql = "SELECT sr_no, name, age, height, weight, mobile, date FROM data";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
					  // output data of each row
					  while($row = $result->fetch_assoc()) {
					?>	
				
					<tr>
						<td><?php echo $row["sr_no"];?></td>
						<td><?php echo $row["name"];?></td>
						<td><?php echo $row["age"];?></td>
						<td><?php echo $row["height"];?></td>
						<td><?php echo $row["weight"];?></td>
						<td><?php echo $row["mobile"];?></td>
						<td><?php echo $row["date"];?></td>
						<td>
						<a href="look.php?id=<?php echo $row["sr_no"];?>"><button class="btn btn-primary" type="button">view</button></a>
						<a href="update.php?id=<?php echo $row["sr_no"]?>"><button class="btn btn-success" type="button">update</button></a>
						<a href="delete.php?id=<?php echo $row["sr_no"]?>"><button class="btn btn-danger">Delete</button></a>
						</td>
					</tr>
					
					<?php	
						
					  }
					} else {
					  echo "0 results";
					}
					$conn->close();
					?>
					
				</tbody>
			</table>
		</div>
	</body>
</html>