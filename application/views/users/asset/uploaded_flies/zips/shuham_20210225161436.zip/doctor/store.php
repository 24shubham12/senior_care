<?php
include 'connection.php';

$fullname=$_POST['fullname'];
$age=$_POST['age'];
$height=$_POST['height'];
$weight=$_POST['weight'];
$mobile=$_POST['mobile'];
$date=$_POST['date'];
 echo $fullname;
 echo $age;
 echo $height;
 echo $weight;
 echo $mobile;
 echo $date;

$sql = "INSERT INTO data (`name`, `age`, `height`, `weight`, `mobile`, `date`)
VALUES ('$fullname', '$age', '$height', '$weight', '$mobile', '$date')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}



?>